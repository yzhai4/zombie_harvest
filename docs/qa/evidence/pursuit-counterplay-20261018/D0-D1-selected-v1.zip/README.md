# Bounded D0 / D1 exact-source diagnostic

Actual executions completed on2026-10-18: D0 PID26864 and D1 PID22604, both
terminal exit0 /6-of-6 contracts. There was no D0/D1 execution failure to erase.
No browser, D2, canonical edit, A03 edit or READY edit occurred.

Use summary.json for concise results and completion-index.json for exact input,
process, source, artifact and writer hashes. Each arm retains execution.json,
stdout/stderr and native/report.json. Its17 referenced artifacts all match SHA.

| Binding | Value |
| --- | --- |
| Complete mother | ae502923d718dd69680599445693a6e71477a84df0e05995bad0d1d34045a842 |
| HTML | ad7627a94ccced73b1ec7222501c13558deb4dd48ebb22ede980cfbf6bd3f65a |
| Paired initial snapshot | 53aa5d5f120ed6cabd312e67a5986fbddbf0be2bee997e4a62b11b5df4f12e07 |
| Same864-frame table | a5c4ece93b2be6d08b8ed77b990d163ef833b8a6a8870e1c6d26af4a9e4de0c0 |

The original full-inline IO factory, registered Continue/key listeners, actual
held RAF, collision and1200ms world interval ran. No direct move/advance or
GameState coordinate/enemy/resource injection was used. Both ran12 actual world
minutes,515 to527, on the same deterministic60Hz frame grid/14,400ms virtual
wall. Existing DOM/render stubs mean this is not Chrome timing equivalence.

D0 stayed at(10.3,11), always hunt/pursued. D1's fixed left100-650ms then up700-
1600ms produced29 movement commands and position(9.2,9.2). At519, actual think
reset with pre-motion distance8.203233 caused wander and enabled rest. Goal
remained the old(10.3,11), not the new player point; the enemy kept walking toward
it. At527 it was still wander,7.618539 from the player. No fresh enemy targetAt,
new damage or7-grid reentry was observed in this bounded window. Null targetId
therefore does not imply a stale memory: the original distance-based hunt is
separate from the real sight/cone/LOS path. No hearing/smell implementation is
claimed, no sensing rule was changed, and no perception bug is presumed.

Both arms transferred actual inventory2 wood +2 parts at519, ending with stock
wood22/parts3/stone12/food7 and project2/2/0. MaterialClock8/workMinutes0 at527;
neither completed engineering. HP86, ten healthy NPCs and building HP were
unchanged; RNG stayed394979344. Input command counts and key boundary positions
support aggregate collision success; per-move return objects were not captured.

Automatic normal writers were at525 while endpoint live was527. A separate,
explicit TEST-ONLY endpoint requestCheckpoint and its actual650ms timeout wrote
527 without another world interval. Each same raw passed strict validation and
actual primary loader/Continue to527, preserving original handoff memory. This
is not an automatic527 save or pagehide rescue; no post-reload tick was added.

The enemy's `think` is the AI decision counter: it resets7->0 at519 and527.
Its separate `perception.clock` resets5->0 at519 and525; at527 it is1->2.
These are distinct counters, and a perception clock reset alone does not prove
a new target. Exact before/after values are retained in summary.json.

The6 checks per arm validate execution and save/loader contracts. The pursuit
trajectories are observations, not extra unique source checks, browser passes,
balance validation or completion of a public gameplay chain.

The first native check's label uses the shorthand day515; its actual assertion
is worldMinute515, which is day1 /08:35. Original reports remain unchanged.
Design interpretation and L0 evidence are in design-review.md; product policy
decisions are a separate read-only review, not an implemented change here.
