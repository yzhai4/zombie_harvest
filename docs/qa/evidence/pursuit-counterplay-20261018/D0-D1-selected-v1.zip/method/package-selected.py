import datetime
import hashlib
import json
import pathlib
import uuid
import zipfile

BASE = pathlib.Path(__file__).resolve().parent
EXPORT = BASE / 'export'
EXPORT.mkdir(exist_ok=True)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def load(path):
    return json.loads(path.read_text(encoding='utf-8'))

def write_new(path, value):
    data = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    with path.open('xb') as handle:
        handle.write(data)
    return data

completion = load(BASE / 'completion-index.json')
runs = []
for arm in ('D0', 'D1'):
    folder = BASE / (arm + '-execution01')
    report = load(folder / 'native/report.json')
    trace = load(folder / 'native/minute-trace.json')
    execution = load(folder / 'execution.json')
    indexed = next(x for x in completion['runs'] if x['arm'] == arm)
    clocks = []
    for tick in trace:
        before = next(x for x in tick['before']['enemies'] if x['id'] == 'wz-4')
        after = next(x for x in tick['after']['enemies'] if x['id'] == 'wz-4')
        clocks.append({
            'worldMinute': tick['after']['worldMinute'],
            'aiThinkBefore': before['think'], 'aiThinkAfter': after['think'],
            'perceptionClockBefore': before['perception']['clock'],
            'perceptionClockAfter': after['perception']['clock'],
            'targetIdAfter': after['perception']['targetId'],
            'targetAtAfter': after['perception']['targetAt'],
            'aiStateAfter': after['aiState'],
            'restGateAfter': tick['after']['restGate'],
        })
    assert [x['worldMinute'] for x in clocks if x['aiThinkBefore'] == 7 and x['aiThinkAfter'] == 0] == [519, 527]
    assert [x['worldMinute'] for x in clocks if x['perceptionClockBefore'] == 5 and x['perceptionClockAfter'] == 0] == [519, 525]
    runs.append({
        'arm': arm, 'terminal': indexed['actualTerminal'],
        'report': indexed['report'], 'methodAndSaveContracts': report['checks'],
        'counts': indexed['counts'], 'writerStages': {
            'automatic': indexed['automaticWriter'],
            'explicitTestOnlyEndpoint': indexed['boundaryWriter'],
            'actualSameRawLoader': indexed['actualSameRawLoader'],
        },
        'observedWz4Counters': clocks,
        'endpointState': clocks[-1]['aiStateAfter'],
        'movement': indexed['movement'],
        'startResources': indexed['startResources'], 'endResources': indexed['endResources'],
        'rngStateStart': indexed['rngStateStart'], 'rngStateEnd': indexed['rngStateEnd'],
        'newDamageCount': indexed['newDamageCount'],
        'freshEnemyTargetAtChanges': indexed['freshEnemyTargetAtChanges'],
    })

summary = {
    'schema': 'PursuitExactBoundedSummaryV1',
    'status': 'ACTUAL_D0_D1_COMPLETE',
    'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source': completion['source'], 'runner': completion['runner'],
    'motherSha256': 'ae502923d718dd69680599445693a6e71477a84df0e05995bad0d1d34045a842',
    'pairControls': completion['pairControls'],
    'scope': {
        'worldMinuteStart': 515, 'worldMinuteEnd': 527, 'actualWorldDeltaPerArm': 12,
        'framesPerArm': 864, 'virtualWallMsPerArm': 14400,
        'endpointSaveTimeoutMs': 650, 'endpointSaveAddsWorldTick': False,
        'executionKind': 'exact-source VM with existing DOM/render stubs and original registered timer/input/collision',
        'countsMeaning': '6 method/save-loader contracts per arm; trajectories are observations, not extra unique source/browser checks',
        'browserRuns': 0, 'D2Runs': 0, 'runtimeEdits': 0, 'postReloadNewTickTested': False,
    },
    'observedResult': {
        'D0': 'stationary; hunt/pursued throughout 515-527',
        'D1': 'fixed left100-650ms/up700-1600ms; at519 aiThink7->0 changes hunt to wander; gate available through527; stored goal remains old player point',
        'classification': 'legacy distance-think hunt and actual visual perception are separate source paths; no new enemy target timestamp in this window',
        'notClaimed': ['perception bug', 'implemented hearing/smell', 'unified ActorObservation', 'permanent safety', 'engineering completion', 'public-chain completion', 'balance validation'],
        'clocks': 'Enemy.think is AI decision timing (resets519/527); enemy.perception.clock is visual refresh timing (resets519/525). Null target is not proof of stale memory.',
        'materials': 'Both actual first staging pulse at519 transfers inventory wood2/parts2 to project2/2/0; endpoint materialClock8/workMinutes0. No free resources.',
        'survival': 'Player HP86 and ten healthy NPCs unchanged; no new damage; building HP unchanged.',
    },
    'runs': runs,
    'finalAudit': {
        'originalNativeReportsUntouched': True,
        'declaredArtifactReferencesPerArm': 17,
        'declaredArtifactReferencesTotal': 34,
        'declaredArtifactShaAndBytesVerified': True,
        'fiveInputBeforeAfterBindingsPerArmUnchanged': True,
        'sameInitialSnapshot': True, 'sameFrameSchedule': True,
        'sameSeedAndRng': True,
        'actualAiThinkAt527CheckedSeparatelyFromPerceptionClock': True,
        'originalAutomatic525AndLive527Separated': True,
        'explicitEndpointCheckpointAndLoaderStagesSeparated': True,
        'A03AndReadyOriginalsUntouched': True,
        'noNewBrowserOrD2OrCanonicalEdit': True,
        'trajectoryObservationsNotAddedToUniqueChecks': True,
    },
    'completionIndex': 'completion-index.json', 'designReview': 'design-review.md',
}
write_new(BASE / 'summary.json', summary)

# Selected review export only. Deduplicate exact bytes; preserve native reports.
entries = {}
by_sha = {}
selections = []
report_maps = []

def select(path, logical, expected=None):
    data = path.read_bytes()
    sha = digest(data)
    if expected:
        assert len(data) == expected['bytes'] and sha == expected['sha256'], str(path)
    if sha not in by_sha:
        entry = logical.replace('\\', '/')
        assert entry not in entries
        entries[entry] = data
        by_sha[sha] = entry
    entry = by_sha[sha]
    item = {'originalPath': str(path), 'logicalName': logical, 'zipEntry': entry, 'bytes': len(data), 'sha256': sha}
    selections.append(item)
    return item

for name in ('README.md', 'summary.json', 'design-review.md', 'completion-index.json'):
    select(BASE / name, name)
for name in ('run-pursuit-exact.mjs', 'method-freeze-execution01.json', 'syntax01-stdout.log', 'syntax01-stderr.log', 'package-selected.py'):
    select(BASE / name, 'method/' + name)
for arm in ('D0', 'D1'):
    folder = BASE / (arm + '-execution01')
    native = folder / 'native'
    report = load(native / 'report.json')
    report_entry = select(native / 'report.json', arm + '/native/report.json')
    for name in ('execution.json', 'stdout.log', 'stderr.log'):
        select(folder / name, arm + '/' + name)
    execution = load(folder / 'execution.json')
    cli_path = EXPORT / (arm + '-actual-cli.json')
    write_new(cli_path, {'schema': 'SelectedActualCliV1', 'derivedFrom': str(folder / 'execution.json'), 'command': execution['command'], 'derivation': 'Exact structured command copied from immutable actual execution record, not a new execution.'})
    select(cli_path, arm + '/actual-cli.json')
    mappings = []
    for artifact in report['artifacts']:
        rel = pathlib.PurePosixPath(artifact['path'])
        assert not rel.is_absolute() and '..' not in rel.parts
        path = (native / artifact['path']).resolve()
        assert path.is_relative_to(native.resolve())
        item = select(path, arm + '/native/' + artifact['path'], artifact)
        mappings.append({'reportArtifactPath': artifact['path'], 'zipEntry': item['zipEntry'], 'bytes': item['bytes'], 'sha256': item['sha256']})
    report_maps.append({'arm': arm, 'nativeReportEntry': report_entry['zipEntry'], 'nativeReportSha256': report_entry['sha256'], 'references': mappings})

inside = {
    'schema': 'PursuitExactSelectedZipIndexV1',
    'scope': 'Selected D0/D1 review export; not a recursive archive, new execution, or new game/browser pass.',
    'nativeReportsPreservedByteForByte': True,
    'deduplication': 'One ZIP entry per identical SHA256; reportArtifactPath maps original references to retained entries.',
    'entryCountExcludingThisIndex': len(entries),
    'selections': selections, 'nativeReportReferenceMaps': report_maps,
    'outsideRetained': [
        {'path': load(BASE / 'D0-execution01/execution.json')['command'][0], 'reason': 'Node runtime executable not archived; launch-time executable SHA was not captured.'},
        {'path': str(pathlib.Path(completion['source']['path']).parent.parent), 'reason': 'Canonical checkout layout and full project/L0/Git tree not recursively copied. Required frozen HTML/IO/factory/input bytes are selected once and mapped above; original absolute CLI paths require original layout or explicit reassembly.'},
        {'path': 'W/next-public-A03-execution01', 'reason': 'Independent earlier public A03 evidence retained outside; not part of this paired12-minute execution.'},
    ],
}
index_bytes = write_new(EXPORT / 'selected-index.json', inside)
entries['selected-index.json'] = index_bytes
zip_path = EXPORT / 'D0-D1-selected-v1.zip'
with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name in sorted(entries):
        info = zipfile.ZipInfo(name, date_time=(2026, 10, 18, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, entries[name], compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)

# Independent read-back into a never-before-used path. Validate traversal before writing.
verify_dir = EXPORT / ('verify-' + uuid.uuid4().hex)
verify_dir.mkdir()
with zipfile.ZipFile(zip_path, 'r') as archive:
    names = archive.namelist()
    assert len(names) == len(set(names)) == len(entries)
    for member in archive.infolist():
        rel = pathlib.PurePosixPath(member.filename)
        assert not rel.is_absolute() and '..' not in rel.parts and ':' not in member.filename and '\\' not in member.filename
        target = (verify_dir / pathlib.Path(*rel.parts)).resolve()
        assert target.is_relative_to(verify_dir.resolve())
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(archive.read(member))
    assert archive.testzip() is None
verified = []
for entry, original in entries.items():
    actual = (verify_dir / entry).read_bytes()
    assert len(actual) == len(original) and digest(actual) == digest(original), entry
    verified.append({'zipEntry': entry, 'bytes': len(actual), 'sha256': digest(actual)})
for mapping in report_maps:
    raw = (verify_dir / mapping['nativeReportEntry']).read_bytes()
    assert digest(raw) == mapping['nativeReportSha256']
    reread = json.loads(raw)
    assert len(reread['artifacts']) == 17
    for ref in mapping['references']:
        raw_artifact = (verify_dir / ref['zipEntry']).read_bytes()
        assert len(raw_artifact) == ref['bytes'] and digest(raw_artifact) == ref['sha256']

receipt = {
    'schema': 'PursuitExactSelectedExportVerifiedV1', 'status': 'SELECTED_ZIP_READBACK_VERIFIED',
    'zip': {'path': str(zip_path), 'bytes': zip_path.stat().st_size, 'sha256': digest(zip_path.read_bytes())},
    'index': {'path': str(EXPORT / 'selected-index.json'), 'zipEntry': 'selected-index.json', 'bytes': len(index_bytes), 'sha256': digest(index_bytes)},
    'verifyDirectory': str(verify_dir), 'pathTraversalChecksPassed': True,
    'verifiedUniqueEntries': len(verified), 'verifiedDeclaredArtifactReferences': 34,
    'nativeReportsOriginalBytesVerified': True,
    'entries': verified, 'scope': inside['scope'],
}
write_new(EXPORT / 'readback-verification.json', receipt)
print(json.dumps({key: receipt[key] for key in ('status', 'zip', 'index', 'verifyDirectory', 'verifiedUniqueEntries', 'verifiedDeclaredArtifactReferences')}, indent=2))
