# D0/D1实际源码诊断与追猎规则设计债

2026-10-18。两臂均实际terminal exit0，D0 PID26864、D1 PID22604，各6/6合同。母输入是完整ae502正常writer，HTML为ad7627a9；未改canonical、原A03、READY方法或存档内容，未启动新browser，未跑D2。CLI、真实进程终态、输入前后SHA及原生报告见completion-index.json。

## 实际执行范围

复用原sourceRuntimeFactory和check-report-recovery IO，执行完整实际inline；保留既有DOM／绘制stub，只增加只读QA别名，不替换感知、Gate、碰撞、reducer或command。没有调用startRuntime、清tasks、强写DAY、直接move／advance或修改坐标、敌状态、资源。真实emit Continue，之后只驱动已注册的任务和输入listener。

两臂使用同初态、seed1592639710、RNG394979344、同epoch、同60Hz全局帧表：864帧／14,400ms受控wall，真实1200ms world interval各12次，实际日历515→527、schedule +12。不是等待12现实分钟，也不是Chrome节拍等价。相同帧时刻先外部输入，再按ID运行到期timer，再运行该帧已注册RAF快照；取消ID不回调，单次任务先从IO Map移除，interval存活才重排。RAF timestamp与Date／performance同域。

D0无移动。D1预先固定ArrowLeft 100–650ms、ArrowUp 700–1600ms，依据原公开的西／西北通路，不读取敌坐标调整。实际listener、held RAF、movement.input及原碰撞运行；27个held帧发起运动命令，加两次keydown的立即运动，共29次0.10上限的输入，最终(10.3,11)→(9.2,9.2)。输入记录在keydown／keyup边界取实际位置；总1.1向西、1.8向北位移与29次上限相合，可推导该段无聚合损失步。没有声称逐次保存了move返回值，也没有把静态路径当成物理执行。

## 关键轨迹

| 分钟 | D0原位 | D1固定西北移动 | 来源判断 |
| --- | --- | --- | --- |
| 515初态 | 玩家(10.3,11)，wz-4 hunt，距6.300052 | 与D0完全相同 | 两份initial-live逐字相同，SHA53aa5d5f… |
| 516 | hunt，距6.235052，Gate pursued | 移动尚未结束，距7.623965，仍hunt／pursued | think未到期；hunt motion取当前玩家，即使旧goal尚未改写。 |
| 518 | hunt，距6.105052 | 玩家已到(9.2,9.2)，距8.203233，仍hunt | 距离拉开后要等原think，不是立即清追踪。 |
| 519 | think重置，pre-distance6.105052，保持hunt | think重置，pre-distance8.203233，转wander；Gate可用 | 两者targetId=null／targetAt=0，均无fresh视觉。差别是原7格距离分支。 |
| 520–526 | 持续hunt，Gate pursued | 持续wander，Gate可用；仍向旧点移动 | D1的goal一直(10.3,11)，与新玩家位置(9.2,9.2)不同。 |
| 527 | think重置，pre-distance5.585052，hunt；距5.520052 | think重置，pre-distance7.683502，wander；距7.618539 | 12分钟内未出现D1重新进入7格，也未出现任何敌人fresh target timestamp。 |

这次实际证明：wander仍消费旧坐标目标，**不是每帧引用移动中的玩家**；但旧点调查也能继续缩短与玩家的距离，不能把wander说成原地停下或长期安全。D1在516–518仍有hunt的当前玩家运动消费者，随后才由think改wander；两种阶段不能合并。

本次没有用延长时间或D2补成重入证据。独立的原A03正常writer（a9ac308f…，t543／seq273）已记录wz-4 hunt、think0、距约6.624985、goal为当时玩家(9.1,9.2)，仍targetId=null／targetAt=0。结合原代码，它支持原A03后来发生距离式重新追猎；这是A03快照加代码的判断，不能说D1的12分钟重演了A03全部24分钟休整。Root另核A03 t554已为nearby-threat及总39分钟取证后果；本诊断不更改那份实际账。

## 工程、存活与保存

两臂都在t519真实筹料首pulse：库存木24→22、零件5→3，工程投入木2／零件2／石0；有relay.materialsGathered原收据及三条inventory来源，causation分别落到各自真实world.advance命令。到527 materialClock8、workMinutes0，仍筹料。不是移动奖励、免费加料或完工。

两臂食物7、玩家HP86不变，体力96→97为原被动再生；没有新combat.damage.applied，十名NPC均HP100／healthy，原建筑耐久未变。RNG全程同394979344；没有新spawn或掩盖敌人。移动改变了真实命令编号／部分感知内容，不把不同策略的账本ID强行相等。

正常自动checkpoint在t525，较晚内存到527，二者明确分开。D0自动writer SHA c2762fe1…；D1为11c3761f…。随后两臂同样调用原requestCheckpoint，明确标记TEST-ONLY终点保存请求，驱动其实际注册650ms timeout；这650ms没有再触发world interval。终点writer527分别为b4115539…与a9a47546…，strict validator通过，再把各自同一完整raw交实际loader，primary checksum分别fd73b207／aabb2792，真实Continue均安装527，原commander本人交付记忆保持。不是pagehide救场，也不冒称自动已保存527。未增加恢复后的新tick实验。

## 7格机制的规则与解释审核

当前明确存在两条不同来源：

- 视觉消费者：updateEnemyPerception→canPerceive，实际读取sight、cone、LOS，写targetId／targetAt。此12分钟两臂都没有fresh target时间戳，不能由null称为陈旧记忆。
- legacy距离追猎：simulateWorldZombies每种类think到期后直接读取玩家全局位置，距离<=7就hunt并设置goal；不经过ActorObservation、视觉授权或刺激事件。hunt motion随后直接消费当前玩家位置。hearing字段存在，但该路径没有听觉消费者；不能把它包装成已实现嗅觉／听觉或完整感知统一。

L0的01第11–16、28、43行要求固定人口、自治、因果及六视角，05第25–34行给敌人生态／弱点，第42行规定“感知→选择目标→移动／攻击→状态更新”；08第5、30行保玩家移动／战斗和防线准备。它们支持敌人有压力、玩家须反制，**没有冻结普通感染者无LOS的7格活体探测、该来源的记忆期限或调查终点重选规则**。双重信号／共鸣设定不能自动补成该普通敌人的感官实现。当前公开休整理由正确给“仍被追踪／附近存在威胁”，没有公开说明7格来源或旧点调查；源码注释“靠近后转追踪”也不是玩家说明。

因此判断为**机制语义与可读性的设计债／待决政策，不是本诊断确认的运行时bug**。原Gate与源规则一致，当前不得悄改。以后若保留距离式警戒，应明确定义它是近距警戒规则、追猎／调查何时结束，并给不泄露隐藏坐标的粗反馈；若改成真实视觉或声音／共鸣刺激，必须先冻结L0／事件事实与消费者，再另验难度和反制，不能只换文案称已实现。完整ActorObservation仍开放，不设成所有下一玩法的无限前置。

## 六视角合理性

| 视角 | 当前实际动机／信息 | 资源、后果与下一选择 |
| --- | --- | --- |
| 玩家 | 已交付核心，想为工程争取时间；只能见粗危险、自己的位置与公开地形 | 固定退避确实有短期作用；原地等候会持续受hunt阻断。成功解除不保证30分钟，更不能保证工程完成。下一策略仍以当前可见入口和生命预算决定。 |
| 营地 | 原有限库存与三岗位继续工程 | 首pulse已实扣库存，防线和人口未受损。工程不因休整拒绝而停摆；玩家走动和世界时间都可推进，不能免费加速绕危险。 |
| NPC | 本人感知／岗位和原交付记忆各有边界 | 十人无伤不等于自动援救；此轮无新救援／关系奖励。可见同ID支援与原2E／15分钟是一条既有有限选择，本轮未测试，不远程调度或凭名册许诺救场。 |
| 势力 | 只认可真实交付／既有贡献 | 不把一次Gate解除当中继上线或增发关系与物资；真实后续工程事实才可接分支。 |
| 敌人 | hunt与调查旧点有运动后果，不能为玩家睡眠失去攻击性 | 当前7格来源读全局玩家，缺少明确L0感官合同。保威胁，但应解释或重定来源；不增设未实现“嗅觉”合理化。 |
| 全局链 | 回收→交付→筹料→工程→当前预警→下一场→恢复 | 这轮证明被拒后移动会改变一段世界反应，存档保来源；尚无新NPC记忆钩子或完整工程／14天通过。manual只影响未来遭遇，不能解除DAY追猎。 |

## 下一公共策略边界

仍需从实际可见提示、已有走过的地形、真实NPC／防御入口作有限决定。可在再中断后选择一段已知退路，或在实际出现同ID守卫／塔入口时按原费用与安全规则处理；不能把本诊断里的精确敌坐标、7格计算或旧goal用作隐藏导航优化，不承诺某一设施或守卫必然清场。若当前可见分支与余预算不足，应停下留真实前缀，而非另造空等、资源、撤退瞬移或放宽Gate。

建议先由Root选择是否补一条忠于当前规则的粗行动说明／防御入口可读性，或先冻结legacy追猎政策；这属于下一产品决策，未实现、未发布。完整14天、最终尸潮、Actor／Planning／Memory／Social、Studio、特殊角色连续性、低频LLM硬软harness、UI素材、大世界／多副本和GameCore／引擎目标均保持。
