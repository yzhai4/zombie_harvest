import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
export const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
export const sliceLimits=Object.freeze({major:3,business:3,ui:18,navigation:18,restAccepted:2,attackAttempts:1,eatAttempts:0,worldMinutes:110,wallMs:180000,ordinaryMs:12000,ordinaryWorldMinutes:8,collisionAlternatives:4});
export function parseArgs(argv){
  const args={},allowed=new Set(['--root','--input','--protocol','--out','--playwright-module','--chrome-executable','--carry','--prior-public-ui','--arm','--expect-html-sha256','--manifest','--mode']);
  assert.equal(argv.length%2,0,'arguments are separate key/value pairs');
  for(let i=0;i<argv.length;i+=2){assert.ok(allowed.has(argv[i]),'known argument '+argv[i]);assert.ok(typeof argv[i+1]==='string'&&argv[i+1]&&!argv[i+1].startsWith('--'),'one scalar value for '+argv[i]);assert.ok(!Object.hasOwn(args,argv[i]),'no duplicate '+argv[i]);args[argv[i]]=argv[i+1];}
  for(const k of allowed)assert.ok(Object.hasOwn(args,k),'required '+k);
  for(const k of ['--root','--input','--protocol','--out','--playwright-module','--chrome-executable','--carry','--prior-public-ui','--manifest'])assert.ok(path.isAbsolute(args[k]),'absolute '+k);
  assert.ok(['validate','run'].includes(args['--mode']));assert.equal(args['--arm'],'A');
  assert.equal(args['--expect-html-sha256'],'ad7627a94ccced73b1ec7222501c13558deb4dd48ebb22ede980cfbf6bd3f65a');
  return args;
}
export function validateBoundInputs(args){
  const manifest=JSON.parse(fs.readFileSync(args['--manifest'],'utf8'));
  assert.equal(manifest.schema,'PublicRelayA03MethodManifestV1');
  for(const [k,value]of Object.entries(manifest.cliBindings))assert.equal(path.normalize(args[k]),path.normalize(value),'exact CLI binding '+k);
  for(const row of manifest.files){const bytes=fs.readFileSync(row.path);assert.equal(sha(bytes),row.sha256,'frozen file '+row.path);assert.equal(bytes.length,row.bytes);}
  assert.ok(!fs.existsSync(args['--out']),'fresh business output, including validation');
  assert.ok(fs.existsSync(args['--chrome-executable']));assert.ok(fs.statSync(args['--chrome-executable']).isFile());
  const carry=JSON.parse(fs.readFileSync(args['--carry'],'utf8')),native=JSON.parse(fs.readFileSync(args['--input'],'utf8'));
  assert.equal(sha(fs.readFileSync(args['--input'])),'ae502923d718dd69680599445693a6e71477a84df0e05995bad0d1d34045a842');
  assert.equal(carry.worldMinutesSpent,164);assert.equal(carry.selectedWorldMinute,515);assert.equal(carry.observedWorldMinute,516);assert.equal(carry.additionalReplayedWorldMinutes,1);assert.equal(carry.deadlineWorldMinute,515+720-164);assert.equal(carry.activeWallMs,146973);
  assert.deepEqual(carry.counts,{major:6,business:6,ui:34,navigation:213,keyMs:32946,restAccepted:1,attackAttempts:2,eatAttempts:1});
  assert.equal(native.payload.day,1);assert.equal(native.payload.hour,8);assert.equal(native.payload.minute,35);assert.equal(native.payload.worldMeta.eventSeq,207);assert.equal(native.payload.relayProject.materialClock,26);assert.equal(native.payload.relayProject.status,'staging');
  return {manifest,carry,native,validationOnly:args['--mode']==='validate'};
}
export function buildSessionOptions(args,plan){
  const result={root:args['--root'],out:args['--out'],input:args['--input'],protocol:args['--protocol'],playwrightModule:args['--playwright-module'],chromeExecutable:args['--chrome-executable'],expectHtml:args['--expect-html-sha256'],expectInput:'ae502923d718dd69680599445693a6e71477a84df0e05995bad0d1d34045a842',budgetCarry:plan.carry,sliceLimits};
  assert.equal(typeof result.chromeExecutable,'string');assert.equal(result.chromeExecutable,args['--chrome-executable']);assert.ok(path.isAbsolute(result.chromeExecutable));assert.equal(result.budgetCarry,plan.carry);assert.equal(result.expectHtml,args['--expect-html-sha256']);
  return result;
}
export function localBudget(carry){
  const global={major:18,business:30,ui:80,navigation:240,keyMs:90000,restAccepted:8,attackAttempts:4,eatAttempts:2};
  return {countCaps:Object.fromEntries(Object.entries(global).map(([k,v])=>[k,Math.min(v,carry.counts[k]+(sliceLimits[k]??v-carry.counts[k]))])),world:Math.min(720-carry.worldMinutesSpent,sliceLimits.worldMinutes),wall:Math.min(900000-carry.activeWallMs,sliceLimits.wallMs),deadline:carry.selectedWorldMinute+720-carry.worldMinutesSpent};
}
export function validActualSession(actual,status,htmlSha){
  return actual.status===status&&Array.isArray(actual.errors)&&actual.errors.length===0&&['contextClosed','browserClosed','serverClosed'].every(k=>actual.cleanup?.[k]===true)&&Array.isArray(actual.documents)&&actual.documents.length>=1&&actual.documents.every(d=>d.sha256===htmlSha&&d.status===200);
}
