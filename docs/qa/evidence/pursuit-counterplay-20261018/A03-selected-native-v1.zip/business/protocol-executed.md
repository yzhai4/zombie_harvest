# Public A03 bounded pursuit continuation - PREPARATION ONLY

No browser or source simulator has been started by preparation. Existing A02 failure remains immutable. Input is the exact normal writer ae502, calendar515; prior live516 is distinct. Explicit ad762 source makes this cross-build controlled continuation, not natural or single-build gameplay.

Carry spent164 with no refund; deadline515+(720-164)=1071. Preserve original counts major6/business6/ui34/navigation213/key32946/rest1/attack2/eat1 and active146973ms, original food corrections and damage. First repeated minute to516 raises cumulative spent165. The1-minute rollback is not added twice before execution.

Only public Continue, visible real context, keys and current/dated-public terrain select goals. Read-only native truth is accounting/conservative veto only. No after-boot state or storage writes, hidden action, direct advance, enemy-coordinate navigation, free rewards or safety changes. Preboot full native injection is TEST-ONLY.

Only the disabled-rest branch gains one bounded known-route relocation, observation and real enabled30/60-minute rest. At most18 new navigation operations,4 collision alternatives,12 seconds AND8 world minutes ordinary observation,2 accepted rests,1 conditional F,110 world minutes,180 seconds,18 UI,3 business/major. Global old balances are also enforced; no food or NPC search. HP<=60 retreat/stop; HP<=35/loss hard stop. Original safety is unchanged. Valid UI or method readiness does not prove path execution or safe disengagement.

Record normal writer at final watermark before reload; never use pagehide to rescue it. Preserve actual loader selection/new tick and no repeated handoff/reward. If normal writer is late, retain negative result and skip reload. Screenshot/read time remains real world cost. Setup and active clocks stay separate. All actual failures retain raw evidence and cleanup. Root authorizes a future run only after exact source/CI completion.
