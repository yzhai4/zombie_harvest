import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createSession} from './pilot-session.mjs';
import {createPublicNavigation} from './public-navigation-v2.mjs';
import {parseArgs,validateBoundInputs,buildSessionOptions,localBudget,validActualSession,sha,sliceLimits} from './method-contract.mjs';

// Validate mode invokes exactly the production argument/options builder below,
// then exits before createSession, server.listen or Chromium can be called.
const args=parseArgs(process.argv.slice(2)),plan=validateBoundInputs(args),options=buildSessionOptions(args,plan),bounds=localBudget(plan.carry);
if(plan.validationOnly){console.log(JSON.stringify({schema:'PublicRelayA03PureCliV1',status:'VALIDATED_ONLY',browserStarted:false,serverStarted:false,sourceHtmlSha256:options.expectHtml,inputSha256:options.expectInput,chromeExecutable:options.chromeExecutable,chromeArgumentIsScalar:typeof options.chromeExecutable==='string',carry:plan.carry.counts,worldMinutesSpent:164,selectedMinute:515,priorObservedMinute:516,deadlineWorldMinute:1071,bounds}));process.exit(0);}

const at=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),minute=v=>(v.day-1)*1440+v.hour*60+v.minute;
const known=new Map(),blockedEdges=new Set(),navigation=createPublicNavigation({known,blockedEdges});
const carry=plan.carry,policy={schema:'PublicRelayA03PolicyV1',status:'PREPARING',sourceHtmlSha256:options.expectHtml,inputSha256:options.expectInput,naturalGameplay:false,humanExperience:false,singleBuild:false,continuation:true,carry,sliceLimits,bounds,decisions:[],normalWriterBeforeReload:null,reloadVerified:false,originalFailureUnchanged:true};
let session,terminal=false,collisions=0,rests=0,attacks=0,ordinaryMs=0,ordinaryWorld=0,lastView,lastAction,lastBudget={...carry.counts},startedHp=null,consequenceSeq=207;
const write=()=>{if(session)fs.writeFileSync(path.join(args['--out'],'policy-decisions.json'),JSON.stringify(policy,null,2)+'\n');};
const note=(kind,reason,v,detail={})=>{policy.decisions.push({kind,reason,at:Date.now(),public:{hp:v.hp,energy:v.energy,day:v.day,hour:v.hour,minute:v.minute,player:v.player,context:v.contextTitle,feedback:v.feedback,buttons:v.buttons},...detail});write();};
function button(v,key){return(v.buttons||[]).find(b=>b.context===key&&!b.disabled);}
function restReason(v){return String(v.feedback?.rest||v.feedback?.restStatus||'');}
function publicTargetSelector(b){assert.ok(b&&!b.disabled&&b.context);let s='[data-context-action='+JSON.stringify(b.context)+']';if(b.enemyId)s+='[data-enemy-id='+JSON.stringify(b.enemyId)+']';return s;}
async function view(){await session.guard();const v=await session.view();navigation.observe(v);lastView=v;if(startedHp===null&&!v.overlayVisible)startedHp=v.hp;return v;}
async function finish(status,reason){if(terminal)return;terminal=true;policy.status=status;policy.reason=reason;policy.endedAt=Date.now();write();return session.finish(status,reason);}
async function perform(spec){const r=await session.perform(spec);lastAction=r.action;lastBudget=r.budget||lastBudget;if(r.stop){terminal=true;policy.status='ACTUAL_METHOD_OR_BUDGET_STOP';policy.reason=r.action?.safety?.reason||'Actual bounded session stopped';write();const e=new Error(policy.reason);e.policyStop=true;throw e;}lastView=r.view;navigation.observe(r.view);return r.view;}
async function bootSelection(label){const selected=await session.page.evaluate(()=>({classification:BootRecovery.classification,installed:BootRecovery.installed,sourceCategory:BootRecovery.selected?.sourceCategory||null,originalChecksum:BootRecovery.selected?.originalChecksum||null,date:BootRecovery.selected?.originalDate||null,eventSeq:BootRecovery.selected?.payload?.worldMeta?.eventSeq??null,worldMinute:BootRecovery.selected?.payload?((BootRecovery.selected.payload.day-1)*1440+BootRecovery.selected.payload.hour*60+BootRecovery.selected.payload.minute):null}));policy[label]=selected;write();assert.equal(selected.classification,'DAY','real loader DAY selection');return selected;}
async function inspectRelay(label){let v=await view();if(!v.modalOpen)await perform({kind:'click',selector:'#openInfoBtn',label:label+'-open',category:'ui'});await perform({kind:'click',selector:'[data-info-tab="build"]',label:label+'-build',category:'ui'});v=await view();assert.ok(v.relay,'actual visible relay panel');note('inspect-relay','Current public panel only; staging is not complete',v,{relay:v.relay});await session.capture(label,true);await perform({kind:'key',key:'Escape',label:label+'-close',category:'ui'});return v;}
async function observeDelay(ms,label,countUi=true){
  assert.ok(ms>0&&ms<=1000);const before=await view();
  if(ordinaryMs+ms>sliceLimits.ordinaryMs||ordinaryWorld+1>sliceLimits.ordinaryWorldMinutes)return false;
  ordinaryMs+=ms;
  if(countUi)await perform({kind:'wait',ms,label,category:'ui'});else await session.page.waitForTimeout(ms);
  const after=await view();ordinaryWorld+=Math.max(0,minute(after)-minute(before));policy.observationBudget={ordinaryMs,ordinaryWorld};write();
  assert.ok(ordinaryWorld<=sliceLimits.ordinaryWorldMinutes,'actual ordinary observation world cap');return true;
}
async function risk(v){
  if(v.night||v.encounter)return 'actual phase changed';if(!Number.isFinite(v.hp)||v.hp<=35)return 'public HP stop';if(v.hp<startedHp||v.hp<=60)return 'public HP harm/retreat threshold';
  // Privileged receipt data can veto further actions, never choose a direction.
  const s=await session.truth(),events=(s?.worldMeta?.events||[]).filter(e=>e.seq>consequenceSeq);consequenceSeq=s?.worldMeta?.eventSeq??consequenceSeq;
  const harm=events.find(e=>e.type==='combat.damage.applied'&&e.payload?.amount>0&&['npc','building','tower'].includes(e.payload?.targetKind));
  if(harm){policy.consequenceVeto={eventId:harm.eventId,type:harm.type,reason:'new non-player combat damage; conservative stop, no hidden destination'};write();return 'conservative non-player damage veto';}
  return null;
}
function retreatCandidate(v){
  const restPresent=(v.buttons||[]).some(b=>/^campRest(30|60)$/.test(b.context||''));if(!restPresent)return null;
  // A real rest affordance plus one nearby public building identifies this
  // local facility. Offsets are fixed before reading any privileged threat.
  const anchors=[...known.values()].filter(t=>t.building&&at(t,v.player)<=1.25);
  if(anchors.length!==1)return null;const a=anchors[0];
  for(const[dx,dy]of [[-.8,-.8],[-1.1,0],[.8,-.8]]){const p={x:a.x+dx,y:a.y+dy,source:'fixed perimeter of actual public rest facility',anchor:{x:a.x,y:a.y}};if(navigation.route(v,p,.30))return p;}
  return null;
}
async function relocate(v){
  const candidate=retreatCandidate(v);if(!candidate)return {ok:false,reason:'no unambiguous public rest facility with a known connected perimeter route'};
  note('bounded-retreat-selected','Fixed public perimeter order; no enemy/native coordinate and no safety promise',v,{candidate});
  for(let n=0;n<18;n++){
    if(lastBudget.navigation-carry.counts.navigation>=18)return {ok:false,reason:'new18 navigation cap'};
    const why=await risk(v);if(why)return {ok:false,reason:why};
    const step=navigation.plan(v,candidate,.30);if(step.arrived){note('bounded-retreat-reached','Measured public position; path succeeded, safety still unknown',v,{candidate});return {ok:true,view:v};}
    if(step.failed)return {ok:false,reason:step.failed};
    const before=v;v=await perform({kind:'key',key:step.key,holdMs:step.holdMs,label:'bounded-public-perimeter-retreat',category:'navigation'});
    if(!navigation.recordMove(before,v,step)){collisions++;note('collision','Original public route records blocked edge',v,{collisions});if(collisions>=Math.min(3,sliceLimits.collisionAlternatives))return {ok:false,reason:'three actual collisions; original stricter limit retained'};}
  }
  return {ok:false,reason:'bounded relocation loop exhausted'};
}
async function restOnce(v,duration){
  v=await view();const beforeRisk=await risk(v);if(beforeRisk)return {ok:false,reason:'pre-commit stop: '+beforeRisk,view:v};
  const b=button(v,'campRest'+duration);assert.ok(b,'real enabled rest required');assert.ok(rests<2);
  const beforeSeq=(await session.truth()).worldMeta.eventSeq;
  note('purposeful-rest','Original public Gate enabled; no extra healing or guaranteed completion',v,{requested:duration});
  await perform({kind:'click',selector:publicTargetSelector(b),label:'bounded-real-rest-'+duration,category:'business'});
  const began=(await session.truth()).worldMeta.events.find(e=>e.seq>beforeSeq&&e.type==='camp.rest.started');
  if(!began)return {ok:false,reason:'visible rest click lacked actual acceptance receipt',view:await view()};rests++;
  const start=Date.now();for(;;){await session.guard();const p=await session.view();lastView=p;const why=await risk(p);if(why)return {ok:false,reason:why,view:p};if(!await session.page.locator('#campRestCancel').isVisible())break;assert.ok(Date.now()-start<90000,'rest observation deadline');await session.page.waitForTimeout(150);}
  v=await view();await session.capture('rest-'+rests+'-actual-terminal',true);note('rest-returned','Actual public controller ended; inspect its real reason and completed minutes',v);
  if(/仍被追踪|附近存在威胁|受损|伤亡|新事项|出现新/.test(restReason(v)))return {ok:false,reason:'actual rest danger/new-matter interruption: '+restReason(v),view:v};
  const stopped=(await session.truth()).worldMeta.events.find(e=>e.type==='camp.rest.stopped'&&e.payload?.restId===began.payload.restId);
  (policy.restAccounting??=[]).push({start:began,stop:stopped||null});write();
  if(!stopped||stopped.payload.completed!==duration||stopped.payload.reason!=='completed')return {ok:false,reason:'actual rest did not complete requested minutes: '+(stopped?.payload?.reason||'missing stop receipt'),view:v};
  return {ok:true,view:v};
}
async function checkpointAndReload(outcome){
  if(await session.page.locator('#campRestCancel').isVisible())await perform({kind:'click',selector:'#campRestCancel',label:'public-cancel-before-outcome',category:'ui'});
  await session.capture('bounded-outcome-before-checkpoint',true);
  const live=await session.truth(),watermark=live.worldMeta.eventSeq,baselineMinute=minute(live),beforeFact={handoffAt:live.relayProject.handoffAt,handoffMemories:live.npcs.filter(n=>n.memory?.relayCoreHandoff).map(n=>({id:n.id,receipt:n.memory.relayCoreHandoff})),relayStatus:live.relayProject.status};
  let raw=null;for(let i=0;i<80;i++){
    const candidate=await session.page.evaluate(()=>localStorage.getItem('zombie-harvest-progress-v12')),p=JSON.parse(candidate).payload;
    if(p.worldMeta.eventSeq>=watermark&&minute(p)>=baselineMinute){raw=candidate;break;}
    if(!await observeDelay(150,'normal-writer-watermark-observation',false))break;
  }
  if(!raw){policy.checkpointFailure={watermark,baselineMinute,reason:'normal writer not observed within original observation budget; no pagehide rescue'};write();return {ok:false,reason:'normal writer watermark unavailable'};}
  const name='normal-outcome-before-reload-native.json';fs.writeFileSync(path.join(args['--out'],name),raw);policy.normalWriterBeforeReload={file:name,sha256:sha(raw),eventSeq:JSON.parse(raw).payload.worldMeta.eventSeq,worldMinute:minute(JSON.parse(raw).payload),observedBeforeReload:true};write();
  await perform({kind:'reload',label:'public-outcome-reload',category:'ui'});
  const selected=await bootSelection('reloadActualSelected');assert.ok(selected.eventSeq>=watermark&&selected.worldMinute>=baselineMinute,'actual selected writer includes pre-reload final watermark');
  await perform({kind:'click',selector:'#continueSaveBtn',label:'public-outcome-continue',category:'ui'});
  const installed=await session.truth(),seq=installed.worldMeta.eventSeq;assert.equal(installed.relayProject.handoffAt,beforeFact.handoffAt);assert.deepEqual(installed.npcs.filter(n=>n.memory?.relayCoreHandoff).map(n=>({id:n.id,receipt:n.memory.relayCoreHandoff})),beforeFact.handoffMemories);
  for(let i=0;i<80;i++){
    await session.guard();const after=await session.truth(),tick=after.worldMeta.events.find(e=>e.seq>seq&&e.type==='time.advanced');
    if(tick){assert.equal(after.relayProject.handoffAt,beforeFact.handoffAt);assert.equal(after.worldMeta.events.filter(e=>e.seq>seq&&['relay.coreHandedOff','relay.stationOnline'].includes(e.type)).length,0);const saved=JSON.parse(await session.page.evaluate(()=>localStorage.getItem('zombie-harvest-progress-v12'))).payload;if(saved.worldMeta.eventSeq>=tick.seq){policy.reloadVerified=true;policy.postReloadTick=tick;await session.capture('public-continue-new-tick',true);write();return {ok:true,outcome};}}
    if(!await observeDelay(150,'new-tick-normal-writer-observation',false))break;
  }
  return {ok:false,reason:'new tick or normal writer not verified within bounded observation'};
}
try{
  session=await createSession(options);
  for(const name of ['run-public-A03.mjs','method-contract.mjs','public-navigation-v2.mjs','carry.json','A02-final-public-ui.json','manifest.json'])fs.copyFileSync(new URL(name,import.meta.url),path.join(args['--out'],name));write();
  const selected=await bootSelection('initialActualSelected');assert.equal(selected.worldMinute,515);assert.equal(selected.eventSeq,207);assert.equal(selected.originalChecksum,plan.native.checksum);
  await perform({kind:'click',selector:'#continueSaveBtn',label:'public-A03-continue',category:'ui'});
  const initialPanel=await inspectRelay('initial-current-project');let v=await view();assert.ok(/筹料中|施工中/.test(initialPanel.relay?.status||''),'A03 starts within public authored engineering slice');
  navigation.observe(JSON.parse(fs.readFileSync(args['--prior-public-ui'],'utf8')));navigation.observe(v);await session.capture('initial-current-public-map',true);
  let outcome={ok:true,reason:'bounded public branch completed'};
  if(!button(v,'campRest30')){
    if(!/仍被追踪/.test(restReason(v)))outcome={ok:false,reason:'current public Gate does not expose pursued; no inferred withdrawal'};
    else outcome=await relocate(v);
    if(outcome.ok){v=await view();for(let i=0;i<9&&!button(v,'campRest30');i++){
      const why=await risk(v);if(why){outcome={ok:false,reason:why};break;}
      if(button(v,'attack')){
        if(attacks>=1||v.hp<70||v.energy<10){outcome={ok:false,reason:'declared conditional F reserve unavailable'};break;}
        const veto=await session.safety(10,'self-defense');if(!veto.allowed){outcome={ok:false,reason:'original conservative F veto: '+veto.reason};break;}
        await perform({kind:'key',key:'f',label:'one-conditional-public-self-defense',category:'self-defense'});attacks++;v=await view();break;
      }
      if(!/仍被追踪/.test(restReason(v))){outcome={ok:false,reason:'different current public Gate: '+restReason(v)};break;}
      if(!await observeDelay(1000,'bounded-public-pursuit-observation')){outcome={ok:false,reason:'ordinary observation cap reached'};break;}v=await view();
    }}
  }
  if(outcome.ok){v=await view();if(!button(v,'campRest30'))outcome={ok:false,reason:'real public rest remains disabled after bounded retreat/observation'};else outcome=await restOnce(v,30);}
  if(outcome.ok){v=await view();if(button(v,'campRest60'))outcome=await restOnce(v,60);else outcome={ok:false,reason:'next real rest unavailable after first request: '+restReason(v)};}
  policy.branchOutcome=outcome;write();
  const persistence=await checkpointAndReload(outcome);policy.persistenceOutcome=persistence;write();
  await finish(outcome.ok&&persistence.ok?'BOUNDED_REST_AND_RELOAD_VERIFIED':outcome.ok?'BOUNDED_REST_WITHOUT_VERIFIED_RELOAD':'BOUNDED_BRANCH_STOPPED',outcome.ok?persistence.reason||'Bounded rest and real recovery verified; engineering not claimed complete':outcome.reason);
}catch(error){if(!error.policyStop)policy.error=String(error.stack||error);write();if(session&&!terminal)await finish('RULE_OR_METHOD_STOP',error.message).catch(()=>{});process.exitCode=1;}
finally{
  if(session){const actual=await session.close();policy.actualFinalCounts=actual.counts;policy.actualCountsDelta=actual.countsDelta;policy.actualWorldMinutesSpent=actual.worldMinutesSpent;policy.actualOrdinaryObservation={ms:ordinaryMs,worldMinutes:ordinaryWorld};policy.cleanup=actual.cleanup;policy.actualSessionStatus=actual.status;policy.actualErrors=actual.errors;policy.requestedTerminalStatus=policy.status;
    const validActual=validActualSession(actual,policy.status,options.expectHtml);
    policy.actualSessionValid=validActual;if(!validActual){policy.status='ACTUAL_SESSION_VALIDATION_FAILED';policy.reason='Actual terminal/errors/cleanup/main-document validation failed; original report retained';}
    write();if(policy.status!=='BOUNDED_REST_AND_RELOAD_VERIFIED'||!validActual)process.exitCode=1;console.log(JSON.stringify({status:policy.status,reason:policy.reason,counts:actual.counts,error:policy.error||null}));}
}
