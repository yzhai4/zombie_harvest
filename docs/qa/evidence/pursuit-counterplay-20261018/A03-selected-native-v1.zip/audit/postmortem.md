# A03 公开续跑独立复盘

实际launcher已TERMINAL/exit1（30.562秒），原生BOUNDED_BRANCH_STOPPED。30分钟休整真实接受，在24分钟时因pursued停止；不是30分钟完成。errors=[]，context/browser/server cleanup均true，两次main均HTTP200/ad7627…。本审计只读原件，未启动游戏或改写报告。

## 实际业务与代价

旧6父业务cmd165/310/459/492/622/746及gross支付完整继承，进食漏计的5→6更正保留，原A02仍失败。新公开退避8段/1289 key ms，从(10.3,11)至(9.1,9.2)，使休整在08:39一度真实可用。新增唯一父业务cmd796 camp.rest.begin；未F、进食、提交第二次60分钟休整。

evt214在519分钟接受30分钟，24条真实step/time收据，evt273在543/09:03以pursued停止，余6。原policy提前返回，没有restAccounting；伴件从原native/live恢复真实收据，未改原报告。

活动HP86→86，新伤害收据0，食物7→7；体力96→98是时间内净再生，无额外休整治疗／补给。10名NPC均100/100健康；旧塔0、补给库4未新增损坏，campCollapse0→0。

筹料两批在519、549，各用库存木2/零件2，总木24→20、零件5→1、石12未动。519批在休整提交前，549批在reload后取证期；不能把两批均记作休整直接产出。终态仍staging：4/10木、4/5零件、0/4石，施工0/180，未完工／上线。

## 水位与预算

输入ae502…是正常writer515/08:35、seq207，旧live516回退1分钟。旧spent164不退款：重走516收第165分钟；最终164+(554−515)=203，旧8分钟回退仍在164。本轮39＝提交前4＋休整24＋停止后reload/观察/取证11。

累计父业务7／尝试7／UI40／导航221／key34235ms／休整2／F2／吃1，活动wall173231ms。原全局余量世界517分钟、wall726769ms、父业务11、尝试23、UI40、导航19、key55765ms、休整6、F2、吃1。整轮110世界分钟／180秒及动作上限未耗尽。

reload前正常writer a9ac…已实际可观测：543/seq273，checksum e83b8197。实际loader选择同543/seq273但checksum68edcd40，**不是同一原始字节**；selected原raw/payload未单独归档。Continue及新tick evt274@544支持同水位和已测交付/材料结果恢复，不能提升为a9ac原raw精确重载。源码pagehide会正常checkpoint，是同水位异checksum的可行机制；缺selected raw，不能认定全部差异仅reason。正常结果在reload前已存在，因此不是靠pagehide补救缺失结果。

最终UI/live554/09:14、seq285；最后观察正常writer553/09:13、seq284，SHA8db89f54…。最终writer没有再次reload，仍有1分钟live/耐久差。

## 方法限制与产品解释

两次Continue原action.hpLoss14是遮罩默认100→恢复86的跨阶段误标，不是28点伤害；report.damage空且全部新收据无伤害。原件保留，伴件更正解释。

ordinary4050ms/6world只统计显式observeDelay窗口。543→554整个验证取证段实际11世界分钟，不能用6宣称全部重载/观察/取证均处于8观察分钟内；所有39已计入203，无全局退款。F安全分支未执行，不称验证过安全脱战。

玩家得到24分钟可用休整前缀；营地付有限材料，NPC人口健康守恒，敌人真实追踪并中断。无新势力动作可评估；全局只推进同日39分钟并恢复一次交付事实。岗亭只加载pack，未消费manual能力，不能归因体验收益。本次未见可据此确认的新产品bug，也不证明软锁、平衡、完工、自然三日或真人体验。后续工程路线仍开放，本审计不启动下一轮。

源码49唯一合同、已接受开发源/CI308与本A03浏览器续跑是不同证据范围；本轮失败或缺selected raw不改写那些独立合同，也不增加unique合同计数。

完整账本见[postmortem.json](postmortem.json)，原件SHA见[evidence-index.json](evidence-index.json)，后续工作流教训仅stage于[workflow-skill-lessons-stage.md](workflow-skill-lessons-stage.md)。无新增全局记忆。
