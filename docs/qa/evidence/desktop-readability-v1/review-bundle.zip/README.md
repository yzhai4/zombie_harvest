# Selected desktop readability evidence

This is a selected archive, not the complete private execution directory. Build SHA256: 86ca99869d174f56287309229cd36017ef69aa92122809c62dd998c16497446f.

desktop-controlled contains the controlled Lin Cen (林岑) fixture at 1440x900, 1280x720 and 1024x768, including context, choice and result screenshots and normal writer outputs. This is controlled UI evidence, not a naturally completed main story.

public-new-game contains the separate normal new-game flow, rest/cancel/continue and wait evidence. Read verification-note.json: the visible clock advanced but savedMinute remained 363. Hidden event cost computed styles are not visible-choice acceptance. Neither flow proves human comprehension, a full natural storyline, mobile behavior, or production acceptance; CSS is not credited with game-resource changes.

The WorkBuddy response and selected receipt concern intermediate candidate 1a6e99f795d7d8fa2d41042dceff7553f615a083d0ee2ee508f5eaed5fcaef5a, not final-build acceptance. Its response exceeded the requested 500 Chinese characters. No intermediate build is archived.

Native reports, writers, scripts and screenshots are preserved byte-for-byte. Original scripts/reports may contain absolute local source/execution paths; these identify provenance only. Configure local paths, dependencies, browser and output directories before reproducing. From build/, run `python -m http.server 8765 --bind 127.0.0.1` and open http://127.0.0.1:8765 for a normal new game. Manual file:// operation was not demonstrated.

Excluded: Chrome profiles/caches, credentials, private CLI diagnostics, full model inputs, intermediate candidate HTML, older 082e screenshots and old 24-file freeze bundle. The companion index records every entry hash and size plus archive hash/size; generated README and selected receipt are marked as derived.
