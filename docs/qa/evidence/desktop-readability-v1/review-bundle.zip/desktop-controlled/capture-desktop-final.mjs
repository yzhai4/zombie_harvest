import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {createServer} from 'node:http';
import {createRequire} from 'node:module';
import assert from 'node:assert/strict';
const root='C:/Users/DELL/AppData/Local/Temp/zh-iteration-20261017-ae1ced87/zombie_harvest-30eeefb5c20e4e8105dfe76e64ce9f806e3373cd';
const work=path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Z]:)/,'$1'));
const out=path.join(work,'desktop-capture02');
fs.mkdirSync(out);
const hash=b=>createHash('sha256').update(b).digest('hex');
const key='zombie-harvest-progress-v12';
const raw=fs.readFileSync(path.join(root,'docs/qa/evidence/npc-relay-stone-v1/selected/blobs/df08b55ad5f2a1c6efcd933ba03f75adf7de3571a99801c596030dc1658bd13f'),'utf8');
const sources={baseline:fs.readFileSync(path.join(work,'../mobile-context-20261019/baseline-082e.html')),candidate:fs.readFileSync(path.join(work,'candidate-final/index.html'))};
const sprites=fs.readFileSync(path.join(root,'dist/actor-sprites.js'));
assert.equal(hash(sources.baseline),'082e8e2e6233351155fb560d4afd0af930b72af1997907733efb936d2654df46');
assert.equal(hash(sources.candidate),'86ca99869d174f56287309229cd36017ef69aa92122809c62dd998c16497446f');
const {chromium}=createRequire(import.meta.url)('C:/Users/DELL/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const report={scope:'Desktop rendered comparison with existing TEST-ONLY near input; no natural or human claim',inputSha256:hash(raw),runnerSha256:hash(fs.readFileSync(new URL(import.meta.url))),scenes:[],errors:[],cleanup:{},beganAt:new Date().toISOString()};
const save=()=>fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2));
const server=createServer((req,res)=>{const u=new URL(req.url,'http://local');const version=u.pathname.split('/')[1];const b=u.pathname.endsWith('actor-sprites.js')?sprites:u.pathname.endsWith('index.html')?sources[version]:null;res.writeHead(b?200:404,{'Content-Type':u.pathname.endsWith('.js')?'text/javascript;charset=utf-8':'text/html;charset=utf-8','Cache-Control':'no-store'});res.end(b||'');});
let browser;const contexts=new Set();
try{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'});report.browserVersion=browser.version();
 for(const version of ['candidate'])for(const viewport of [{width:1440,height:900},{width:1280,height:720},{width:1024,height:768}]){
  const name=version+'-'+viewport.width,scene={name,viewport,sourceHtmlSha256:hash(sources[version]),startedAt:Date.now(),actions:[]};report.scenes.push(scene);
  const context=await browser.newContext({viewport});contexts.add(context);
  try{
   await context.addInitScript(({raw,key})=>{if(!sessionStorage.getItem('desktop-capture-seed')){localStorage.setItem(key,raw);sessionStorage.setItem('desktop-capture-seed','once');}},{raw,key});
   const page=await context.newPage();page.setDefaultTimeout(4000);page.on('pageerror',e=>report.errors.push({scene:name,error:e.message}));
   const response=await page.goto('http://127.0.0.1:'+server.address().port+'/'+version+'/index.html',{waitUntil:'domcontentloaded'});assert.equal(hash(await response.body()),scene.sourceHtmlSha256);
   await page.locator('#continueSaveBtn').click();scene.actions.push('Continue existing TEST-ONLY fixture');
   const entry=page.locator('[data-context-action="npcRelayStone"][data-npc-id="commander"]');
   await entry.scrollIntoViewIfNeeded();
   scene.context=await entry.evaluate(e=>({text:e.innerText,font:getComputedStyle(e).fontSize,smallFont:getComputedStyle(e.querySelector('small')).fontSize,smallColor:getComputedStyle(e.querySelector('small')).color,buttonColor:getComputedStyle(e).color,background:getComputedStyle(e).backgroundColor,rect:e.getBoundingClientRect().toJSON(),container:document.getElementById('contextPanel').getBoundingClientRect().toJSON()}));
   await page.screenshot({path:path.join(out,name+'-context.png')});
   await entry.click();scene.actions.push('open Lin Cen offer');
   await page.locator('#eventChoiceA').scrollIntoViewIfNeeded();
   scene.choices=await page.evaluate(()=>['eventChoiceA','eventChoiceB'].map(id=>{const e=document.getElementById(id),r=e.getBoundingClientRect(),s=e.querySelector('small');return{id,text:e.innerText,font:getComputedStyle(e).fontSize,smallFont:s?getComputedStyle(s).fontSize:null,rect:r.toJSON(),disabled:e.disabled,inViewport:r.left>=0&&r.top>=0&&r.right<=innerWidth&&r.bottom<=innerHeight,hit:e.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2)),choice:e.dataset.eventChoiceId};}));
   scene.event=await page.locator('#eventText').evaluate(e=>({text:e.innerText,font:getComputedStyle(e).fontSize,rect:e.getBoundingClientRect().toJSON()}));
   assert.ok(scene.choices.every(b=>b.inViewport&&b.hit&&!b.disabled),'both choices visible, enabled and hit-testable');
   await page.screenshot({path:path.join(out,name+'-choices.png')});
   if(version==='candidate'){
    const choice=viewport.width===1440?'supply':'later';
    const button=scene.choices.find(b=>b.choice===choice);assert.ok(button);
    await page.locator('#'+button.id).click();scene.actions.push(choice);
    await page.waitForFunction(({key,choice})=>{const p=JSON.parse(localStorage.getItem(key)||'null')?.payload;return !!p?.worldMeta?.events?.find(e=>e.type==='content.chain.resolved'&&e.payload?.chainId==='npc-relay-stone-001'&&e.payload.choiceId===choice);},{key,choice});
    const writer=await page.evaluate(key=>localStorage.getItem(key),key);fs.writeFileSync(path.join(out,name+'-normal-writer.json'),writer);
    const p=JSON.parse(writer).payload;
    scene.after={stone:p.stone,materialProgress:p.relayProject.materialProgress,events:p.worldMeta.events.filter(e=>/stone|chain.resolved/.test(e.type)).slice(-5),flags:p.contentState.flags};
    await page.screenshot({path:path.join(out,name+'-result.png')});
   }
   scene.ok=true;
  }catch(e){scene.ok=false;scene.error=String(e.stack||e);report.errors.push({scene:name,error:String(e.message)});}
  finally{scene.elapsedMs=Date.now()-scene.startedAt;await context.close();contexts.delete(context);save();}
 }
}catch(e){report.errors.push({error:String(e.stack||e)});}
finally{for(const context of contexts)await context.close();if(browser)await browser.close();if(server.listening)await new Promise(r=>server.close(r));report.cleanup={contextsClosed:true,browserClosed:!browser?.isConnected(),serverClosed:!server.listening};report.ok=!report.errors.length&&report.scenes.length===3&&report.scenes.every(s=>s.ok);save();console.log(JSON.stringify({ok:report.ok,scenes:report.scenes.map(s=>({name:s.name,ok:s.ok,elapsedMs:s.elapsedMs,actions:s.actions})),errors:report.errors,cleanup:report.cleanup}));if(!report.ok)process.exitCode=1;}
