import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {createServer} from 'node:http';
import {fileURLToPath} from 'node:url';

const scriptStarted=performance.now();
const out=path.dirname(fileURLToPath(import.meta.url));
const hash=b=>createHash('sha256').update(b).digest('hex');
const html=fs.readFileSync(path.join(out,'source.html'));
const sprites=fs.readFileSync(path.join(out,'actor-sprites.js'));
const expected='86ca99869d174f56287309229cd36017ef69aa92122809c62dd998c16497446f';
const saveKey='zombie-harvest-progress-v12';
const report={runner:'desktop-public-ui-final01-single-attempt-20261019',sourceHtmlSha256:hash(html),spritesSha256:hash(sprites),runnerSha256:hash(fs.readFileSync(fileURLToPath(import.meta.url))),scope:'Independent desktop public UI regression; neither natural mainline nor human acceptance. Resource changes are not attributed to CSS.',freshContext:true,viewport:{width:1440,height:900},stateInjection:false,hiddenNavigation:false,speedChange:false,enemyRemoval:false,uiOperations:[],movements:[],views:[],captures:[],documents:[],writerReceipts:[],errors:[],blockedRequests:[],cleanup:{},verdict:'not-run'};
const elapsed=()=>Math.round(performance.now()-scriptStarted);
const write=()=>fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
const budget=()=>{if(elapsed()>18500)throw new Error('BUDGET_STOP: 18.5 s operation deadline, leaving cleanup margin');};
let browser,context,page,server,deadline;
const require=createRequire(import.meta.url);
const {chromium}=require('C:/Users/DELL/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');

async function view(label){
 budget();
 const v=await page.evaluate(()=>{
  const selectors=['#dayLabel','#timeLabel','#basicEnergyValue','#basicHpValue','#hpValue','#contextPanel','#contextTitle','#contextHint','#campRestFeedback','#campRestStatus','#campRestCancel','[data-context-action="campRest30"]','[data-context-action="campRest60"]','#eventTitle','#eventText','#eventChoiceA','#eventChoiceA small','#eventChoiceB','#eventChoiceB small','#overviewLocation'];
  const result={};
  for(const selector of selectors){
   const e=document.querySelector(selector);if(!e){result[selector]={present:false};continue;}
   const r=e.getBoundingClientRect(),s=getComputedStyle(e);
   let visible=r.width>0&&r.height>0&&r.bottom>0&&r.top<innerHeight&&r.right>0&&r.left<innerWidth;
   for(let n=e;n&&visible;n=n.parentElement){const style=getComputedStyle(n);if(style.display==='none'||style.visibility==='hidden'||Number(style.opacity)===0)visible=false;}
   const center={x:r.x+r.width/2,y:r.y+r.height/2},hit=visible?document.elementFromPoint(center.x,center.y):null;
   result[selector]={present:true,visible,text:visible?e.innerText:null,disabled:'disabled'in e?e.disabled:undefined,rect:{x:r.x,y:r.y,width:r.width,height:r.height,top:r.top,left:r.left,bottom:r.bottom,right:r.right},center,centerHit:hit?{targetOrDescendant:e.contains(hit),tag:hit.tagName,id:hit.id,contextAction:hit.getAttribute('data-context-action')}:null,fontSize:s.fontSize,lineHeight:s.lineHeight,color:s.color,ariaDescribedBy:e.getAttribute('aria-describedby')};
  }
  result.contextActionText=[...document.querySelectorAll('#contextActions button,#contextActions button small')].map(e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e),visible=r.width>0&&r.height>0&&r.bottom>0&&r.top<innerHeight&&r.left>=0&&r.right<=innerWidth,center={x:r.x+r.width/2,y:r.y+r.height/2},hit=visible?document.elementFromPoint(center.x,center.y):null;return {tag:e.tagName,visible,text:visible?e.innerText:null,rect:{x:r.x,y:r.y,width:r.width,height:r.height,top:r.top,left:r.left,right:r.right,bottom:r.bottom},center,centerHit:hit?{targetOrDescendant:e.contains(hit),tag:hit.tagName,id:hit.id,contextAction:hit.getAttribute('data-context-action')}:null,fontSize:s.fontSize,lineHeight:s.lineHeight,color:s.color};});
  return result;
 });
 const hpField=v['#basicHpValue'].visible?v['#basicHpValue']:v['#hpValue'];
 const hp=hpField.visible?Number.parseFloat(hpField.text):null;
 const calendar=[v['#dayLabel']?.text,v['#timeLabel']?.text].join(' | ');
 const item={label,elapsedMs:elapsed(),hp,calendar,public:v};report.views.push(item);write();
 if(hp!==null&&hp<65)throw new Error('HP_STOP: visible HP '+hp+' < 65');
 return item;
}
async function shot(label){budget();const bytes=await page.screenshot({path:path.join(out,label+'.png'),timeout:650});report.captures.push({file:label+'.png',elapsedMs:elapsed(),sha256:hash(bytes)});write();}
async function action(name,fn){budget();if(report.uiOperations.length>=10)throw new Error('UI_OPERATION_LIMIT');const a={name,startedMs:elapsed()};report.uiOperations.push(a);write();try{await fn();a.ok=true;}catch(e){a.ok=false;a.error=String(e);throw e;}finally{a.finishedMs=elapsed();write();}}
async function writer(label){
 budget();const raw=await page.evaluate(key=>localStorage.getItem(key),saveKey);
 if(!raw)throw new Error('No normal writer save after '+label);
 const file=label+'-native-writer.json';fs.writeFileSync(path.join(out,file),raw);
 const parsed=JSON.parse(raw),events=parsed?.payload?.worldMeta?.events;
 if(!Array.isArray(events))throw new Error('Normal writer has no event receipts');
 const receipts=events.filter(e=>e.type==='camp.rest.started'||e.type==='camp.rest.stopped'||e.type==='camp.rest.stepped');
 const result={label,file,elapsedMs:elapsed(),sha256:hash(Buffer.from(raw)),savedMinute:parsed.savedAt,food:parsed.payload.food,energy:parsed.payload.energy,receipts,timeReceipts:events.filter(e=>e.type==='time.advanced'),startedCount:events.filter(e=>e.type==='camp.rest.started').length,stoppedCount:events.filter(e=>e.type==='camp.rest.stopped').length};
 report.writerReceipts.push(result);write();return result;
}
async function documentCheck(response,label){const actual=hash(await response.body());report.documents.push({label,sha256:actual,elapsedMs:elapsed()});if(actual!==expected)throw new Error('Actual document hash mismatch');}

try{
 if(report.sourceHtmlSha256!==expected)throw new Error('Frozen source hash mismatch');
 if(fs.existsSync(path.join(out,'run-started.json')))throw new Error('Single attempt already started');
 fs.writeFileSync(path.join(out,'run-started.json'),JSON.stringify({at:new Date().toISOString(),sourceHtmlSha256:expected})+'\n');
 write();
 server=createServer((req,res)=>{const route=new URL(req.url,'http://127.0.0.1').pathname;const data=route==='/'||route==='/index.html'?html:route==='/actor-sprites.js'?sprites:null;res.writeHead(data?200:404,{'Content-Type':route.endsWith('.js')?'text/javascript;charset=utf-8':'text/html;charset=utf-8','Cache-Control':'no-store'});res.end(data||'');});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 report.loopback='http://127.0.0.1:'+server.address().port;
 browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'});report.browserVersion=browser.version();
 context=await browser.newContext({viewport:report.viewport});
 await context.route('**/*',route=>{const u=new URL(route.request().url());if(u.origin===report.loopback&&['/','/index.html','/actor-sprites.js'].includes(u.pathname))return route.continue();report.blockedRequests.push(u.href);return route.abort();});
 page=await context.newPage();page.setDefaultTimeout(900);page.on('pageerror',error=>{report.errors.push({type:'pageerror',message:error.message,elapsedMs:elapsed()});write();});
 deadline=setTimeout(()=>{report.errors.push({type:'deadline',message:'Hard 20 s runtime cutoff',elapsedMs:elapsed()});write();browser?.close().catch(()=>{});},Math.max(1,20000-elapsed()));
 let response;
 await action('navigate frozen loopback HTML',async()=>{response=await page.goto(report.loopback+'/',{waitUntil:'domcontentloaded',timeout:1500});});
 await documentCheck(response,'initial');
 await action('normal Continue / new game',()=>page.locator('#continueSaveBtn').click());
 await page.waitForTimeout(180);
 await view('new-game');await shot('01-new-game');
 for(let n=1;n<=4;n++){
  budget();const m={key:'a',durationMs:80,startedMs:elapsed()};report.movements.push(m);await page.keyboard.press('a',{delay:80});m.finishedMs=elapsed();await page.waitForTimeout(80);await view('move-'+n);
 }
 await page.waitForTimeout(350);
 let v=await view('after-four-moves');await shot('02-after-four-moves');
 let rest=v.public['[data-context-action="campRest60"]'];
 if(!(rest.present&&rest.visible&&!rest.disabled)){
  await action('single public map click at visible camp (1055,358)',()=>page.mouse.click(1055,358));await page.waitForTimeout(180);v=await view('after-camp-click');await shot('03-after-camp-click');rest=v.public['[data-context-action="campRest60"]'];
 }
 if(!(rest.present&&rest.visible&&!rest.disabled)){report.verdict='blocked-rest-unavailable';report.stopReason=v.public['#campRestFeedback']?.text||v.public['#contextHint']?.text||'campRest60 not visible and enabled';throw new Error('PUBLIC_REST_BLOCKED: '+report.stopReason);}
 await action('ordinary campRest60 click',()=>page.locator('[data-context-action="campRest60"]').click());
 let observedProgress=false;
 while(elapsed()<15000){
  v=await view('rest-progress');const status=v.public['#campRestStatus']?.text||'';const match=status.match(/(\d+)\/60\s*分钟/);
  if(match&&Number(match[1])>=1){observedProgress=true;report.observedProgressMinutes=Number(match[1]);break;}
  if(v.public['#campRestCancel']?.disabled||!v.public['#campRestCancel']?.visible)throw new Error('Rest stopped before one public minute: '+status);
  await page.waitForTimeout(150);
 }
 if(!observedProgress)throw new Error('No one-minute public rest progress within bounded runtime');
 await shot('04-rest-progress');
 await action('ordinary campRestCancel click',()=>page.locator('#campRestCancel').click());
 await page.waitForTimeout(180);await view('cancelled');await shot('05-cancelled');
 const before=await writer('after-cancel');
 if(before.startedCount!==1||before.stoppedCount!==1)throw new Error('Expected exactly one started and one stopped native receipt');
 const stop=before.receipts.findLast(e=>e.type==='camp.rest.stopped');report.actualStopReceipt=stop;
 if(stop?.payload?.reason!=='player-cancel'||!(stop?.payload?.completed>=1))throw new Error('Cancel receipt missing paid-time prefix');
 await action('reload',async()=>{response=await page.reload({waitUntil:'domcontentloaded',timeout:1500});});await documentCheck(response,'reload');
 await action('normal Continue after reload',()=>page.locator('#continueSaveBtn').click());
 const resumeView=await view('continue-before-clock-change'),resumeWriter=await writer('continue-before-clock-change');
 const clockWaitStarted=elapsed();let clockView=resumeView;
 while(elapsed()-clockWaitStarted<3000){await page.waitForTimeout(100);clockView=await view('continue-clock-observation');if(clockView.calendar!==resumeView.calendar)break;}
 report.publicClock={before:resumeView.calendar,after:clockView.calendar,changed:clockView.calendar!==resumeView.calendar,waitElapsedMs:elapsed()-clockWaitStarted};
 await shot('06-continue-new-timer');
 const after=await writer('after-continue-new-timer');
 report.noDuplicateRestStarted=after.startedCount===before.startedCount;
 report.writerAfterContinue={beforeSavedMinute:resumeWriter.savedMinute,afterSavedMinute:after.savedMinute,minuteDelta:after.savedMinute-resumeWriter.savedMinute,shaChanged:after.sha256!==resumeWriter.sha256,foodDelta:after.food-resumeWriter.food,energyDelta:after.energy-resumeWriter.energy,startedDelta:after.startedCount-resumeWriter.startedCount,stoppedDelta:after.stoppedCount-resumeWriter.stoppedCount};
 if(!report.noDuplicateRestStarted)throw new Error('Duplicate rest.started after normal Continue');
 if(!report.publicClock.changed)throw new Error('No new public calendar minute observed within 3 seconds after Continue');
 report.verdict=report.errors.length?'completed-with-errors':'pass';
}catch(error){
 if(report.verdict==='not-run')report.verdict='stopped-or-failed';
 report.errors.push({type:'single-attempt',message:String(error.stack||error),elapsedMs:elapsed()});
}finally{
 report.uiElapsedMs=elapsed();if(deadline)clearTimeout(deadline);
 if(context)await context.close().then(()=>report.cleanup.contextClosed=true).catch(e=>report.cleanup.contextError=String(e));
 if(browser)await browser.close().then(()=>report.cleanup.browserClosed=true).catch(e=>report.cleanup.browserError=String(e));
 if(server?.listening)await new Promise(resolve=>server.close(resolve));report.cleanup.serverClosed=!server?.listening;
 report.elapsedMs=elapsed();report.uiOperationCount=report.uiOperations.length;report.movementCount=report.movements.length;write();
 console.log(JSON.stringify({verdict:report.verdict,sourceHtmlSha256:report.sourceHtmlSha256,elapsedMs:report.elapsedMs,uiOperationCount:report.uiOperationCount,movementCount:report.movementCount,stopReason:report.stopReason,observedProgressMinutes:report.observedProgressMinutes,noDuplicateRestStarted:report.noDuplicateRestStarted,publicClock:report.publicClock,writerAfterContinue:report.writerAfterContinue,cleanup:report.cleanup,errors:report.errors}));
 if(report.verdict!=='pass')process.exitCode=1;
}
