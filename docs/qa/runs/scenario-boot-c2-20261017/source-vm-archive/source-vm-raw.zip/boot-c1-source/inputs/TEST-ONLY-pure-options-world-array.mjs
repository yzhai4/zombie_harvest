export default {"worldConfig":[]};
