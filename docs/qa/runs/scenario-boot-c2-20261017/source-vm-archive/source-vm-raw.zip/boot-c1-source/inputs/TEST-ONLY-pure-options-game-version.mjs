export default {"gameVersion":"future"};
