export default {"difficultyProfile":"hard"};
