export default {"worldConfig":null};
