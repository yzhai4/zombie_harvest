export default {"difficultyProfile":"impossible"};
